#!/bin/sh
sed -i \
         -e 's/#1e1e1e/rgb(0%,0%,0%)/g' \
         -e 's/#e0e0e0/rgb(100%,100%,100%)/g' \
    -e 's/#2c2c2c/rgb(50%,0%,0%)/g' \
     -e 's/#eed714/rgb(0%,50%,0%)/g' \
     -e 's/#2a2a2a/rgb(50%,0%,50%)/g' \
     -e 's/#fff1f3/rgb(0%,0%,50%)/g' \
	"$@"
